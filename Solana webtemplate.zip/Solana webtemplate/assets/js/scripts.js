new WOW().init();

$(document).ready(function () {

    $('.counter').counterUp({
        delay: 10,
        time: 1500
    });

    $('.menu-btn-1').click(function(){
        $('.nav-links').toggle()
        $('.nav-links').toggleClass('h-class')

    })

});

function menuBtnFunction(menuBtn) {
    menuBtn.classList.toggle("active");
}

let valOdo = 163077581394;

setInterval(function () {
    valOdo += 50;
    odometer.innerHTML = valOdo;
}, 500)

